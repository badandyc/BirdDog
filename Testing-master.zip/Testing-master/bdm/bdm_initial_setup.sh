#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Run as root: sudo bash bdm_initial_setup"
  exit 1
fi

echo "=== BirdDog BDM Bootstrap ==="

# Disable cloud-init if present
if [ -d /etc/cloud ]; then
  echo "Disabling cloud-init..."
  touch /etc/cloud/cloud-init.disabled
fi

# Prompt for hostname
read -p "Enter new hostname (e.g. bdm-01): " NEW_HOSTNAME

if [[ -z "$NEW_HOSTNAME" ]]; then
  echo "Hostname cannot be empty."
  exit 1
fi

echo "Setting hostname to $NEW_HOSTNAME"

echo "$NEW_HOSTNAME" > /etc/hostname

if grep -q "^127.0.1.1" /etc/hosts; then
  sed -i "s/^127.0.1.1.*/127.0.1.1    $NEW_HOSTNAME/" /etc/hosts
else
  echo "127.0.1.1    $NEW_HOSTNAME" >> /etc/hosts
fi

hostname "$NEW_HOSTNAME"

echo "Installing Avahi..."
apt update
apt install -y avahi-daemon

rm -rf /var/lib/avahi-daemon/* || true

systemctl enable avahi-daemon
systemctl restart avahi-daemon

echo "=== Determining mesh IP ==="

HOST=$(hostname)

if [[ $HOST =~ bdm-([0-9]+) ]]; then
  ID=${BASH_REMATCH[1]}
  MESH_IP="10.10.20.$ID"
else
  echo "ERROR: Hostname must follow pattern bdm-XX"
  exit 1
fi

echo "Mesh IP will be $MESH_IP"

echo "Configuring systemd-networkd for mesh..."

mkdir -p /etc/systemd/network

cat > /etc/systemd/network/30-mesh.network <<EOF
[Match]
Name=wlan1

[Network]
Address=${MESH_IP}/24
EOF

systemctl enable systemd-networkd
systemctl restart systemd-networkd

echo "Updating system..."
#apt full-upgrade -y
#apt autoremove -y

echo "=== Bootstrap complete ==="
echo "Hostname: $NEW_HOSTNAME"
echo "Mesh IP: $MESH_IP"

echo "Rebooting in 5 seconds..."
sleep 5
reboot
